package com.example.myapplication

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.EditText
import android.widget.Toast
import androidx.fragment.app.Fragment
import com.google.firebase.auth.EmailAuthProvider
import com.google.firebase.auth.FirebaseAuth

class ChangePhoneFragment : Fragment() {

    private lateinit var editTextCurrentEmail: EditText
    private lateinit var editTextPassword: EditText
    private lateinit var editTextNewPhone: EditText
    private lateinit var buttonConfirmChange: Button

    private lateinit var auth: FirebaseAuth

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        val view = inflater.inflate(R.layout.fragment_change_phone, container, false)

        editTextCurrentEmail = view.findViewById(R.id.editTextCurrentEmail)
        editTextPassword = view.findViewById(R.id.editTextPassword)
        editTextNewPhone = view.findViewById(R.id.editTextNewPhone)
        buttonConfirmChange = view.findViewById(R.id.buttonConfirmChange)

        auth = FirebaseAuth.getInstance()

        buttonConfirmChange.setOnClickListener {
            val currentEmail = editTextCurrentEmail.text.toString().trim()
            val password = editTextPassword.text.toString().trim()
            val newPhone = editTextNewPhone.text.toString().trim()

            if (currentEmail.isEmpty() || password.isEmpty() || newPhone.isEmpty()) {
                Toast.makeText(context, "Wprowadź wszystkie dane", Toast.LENGTH_SHORT).show()
            } else {
                reauthenticateAndChangePhone(currentEmail, password, newPhone)
            }
        }

        return view
    }

    private fun reauthenticateAndChangePhone(currentEmail: String, password: String, newPhone: String) {
        val user = auth.currentUser
        if (user != null && user.email != null) {
            val credential = EmailAuthProvider.getCredential(user.email!!, password)

            user.reauthenticate(credential)
                .addOnCompleteListener { task ->
                    if (task.isSuccessful) {
                        // Tutaj dodaj logikę do zmiany numeru telefonu
                        // Może być konieczne użycie innej metody Firebase Authentication do zmiany numeru telefonu
                        Toast.makeText(context, "Numer telefonu zmieniony pomyślnie na: $newPhone", Toast.LENGTH_SHORT).show()
                    } else {
                        Toast.makeText(context, "Ponowne uwierzytelnienie nie powiodło się: ${task.exception?.message}", Toast.LENGTH_SHORT).show()
                    }
                }
        } else {
            Toast.makeText(context, "Nie można pobrać aktualnego użytkownika.", Toast.LENGTH_SHORT).show()
        }
    }
}
