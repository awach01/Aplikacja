package com.example.myapplication

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.EditText
import android.widget.Toast
import androidx.fragment.app.Fragment
import com.google.firebase.auth.EmailAuthProvider
import com.google.firebase.auth.FirebaseAuth

class ChangeEmailFragment : Fragment() {

    private lateinit var editTextCurrentEmail: EditText
    private lateinit var editTextNewEmail: EditText
    private lateinit var editTextPassword: EditText
    private lateinit var buttonConfirmChange: Button

    private lateinit var auth: FirebaseAuth

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        val view = inflater.inflate(R.layout.fragment_change_email, container, false)

        editTextCurrentEmail = view.findViewById(R.id.editTextCurrentEmail)
        editTextNewEmail = view.findViewById(R.id.editTextNewEmail)
        editTextPassword = view.findViewById(R.id.editTextPassword)
        buttonConfirmChange = view.findViewById(R.id.buttonConfirmChange)

        auth = FirebaseAuth.getInstance()

        buttonConfirmChange.setOnClickListener {
            val currentEmail = editTextCurrentEmail.text.toString().trim()
            val newEmail = editTextNewEmail.text.toString().trim()
            val password = editTextPassword.text.toString().trim()

            if (currentEmail.isEmpty() || newEmail.isEmpty() || password.isEmpty()) {
                Toast.makeText(context, "Wprowadź wszystkie dane", Toast.LENGTH_SHORT).show()
            } else if (currentEmail == newEmail) {
                Toast.makeText(context, "Nowy adres e-mail nie może być taki sam jak aktualny", Toast.LENGTH_SHORT).show()
            } else {
                reauthenticateAndChangeEmail(currentEmail, newEmail, password)
            }
        }

        return view
    }

    private fun reauthenticateAndChangeEmail(currentEmail: String, newEmail: String, password: String) {
        val user = auth.currentUser
        if (user != null && user.email != null) {
            val credential = EmailAuthProvider.getCredential(user.email!!, password)

            user.reauthenticate(credential)
                .addOnCompleteListener { task ->
                    if (task.isSuccessful) {
                        user.updateEmail(newEmail)
                            .addOnCompleteListener { updateTask ->
                                if (updateTask.isSuccessful) {
                                    sendVerificationEmail(auth)
                                } else {
                                    Toast.makeText(context, "Błąd podczas zmiany adresu e-mail: ${updateTask.exception?.message}", Toast.LENGTH_SHORT).show()
                                }
                            }
                    } else {
                        Toast.makeText(context, "Ponowne uwierzytelnienie nie powiodło się: ${task.exception?.message}", Toast.LENGTH_SHORT).show()
                    }
                }
        } else {
            Toast.makeText(context, "Nie można pobrać aktualnego użytkownika.", Toast.LENGTH_SHORT).show()
        }
    }

    private fun sendVerificationEmail(user: FirebaseAuth) {
        user.currentUser?.sendEmailVerification()
            ?.addOnCompleteListener { task ->
                if (task.isSuccessful) {
                    Toast.makeText(context, "Wysłano e-mail weryfikacyjny na nowy adres e-mail. Kliknij link weryfikacyjny, aby zmienić adres e-mail.", Toast.LENGTH_LONG).show()
                } else {
                    Toast.makeText(context, "Błąd podczas wysyłania e-maila weryfikacyjnego: ${task.exception?.message}", Toast.LENGTH_SHORT).show()
                }
            }
    }
}
