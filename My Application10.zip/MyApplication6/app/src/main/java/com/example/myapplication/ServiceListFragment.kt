package com.example.myapplication

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.Toast
import androidx.fragment.app.Fragment
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.firestore.FirebaseFirestore

class ServiceListFragment : Fragment() {

    private lateinit var serviceListLayout: LinearLayout
    private lateinit var editTextService: EditText
    private lateinit var buttonAddService: Button
    private lateinit var auth: FirebaseAuth
    private lateinit var db: FirebaseFirestore

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        val view = inflater.inflate(R.layout.fragment_service_list, container, false)
        serviceListLayout = view.findViewById(R.id.serviceListLayout)
        editTextService = view.findViewById(R.id.editTextService)
        buttonAddService = view.findViewById(R.id.buttonAddService)

        auth = FirebaseAuth.getInstance()
        db = FirebaseFirestore.getInstance()

        buttonAddService.setOnClickListener {
            val service = editTextService.text.toString()
            if (service.isNotEmpty()) {
                addService(service)
            } else {
                Toast.makeText(context, "Please enter a service", Toast.LENGTH_SHORT).show()
            }
        }

        loadServices()

        return view
    }

    private fun addService(service: String) {
        val user = auth.currentUser
        if (user != null) {
            val serviceData = hashMapOf(
                "service" to service,
                "userId" to user.uid
            )
            db.collection("services")
                .add(serviceData)
                .addOnSuccessListener {
                    Toast.makeText(context, "Service added", Toast.LENGTH_SHORT).show()
                    loadServices()
                }
                .addOnFailureListener { e ->
                    Toast.makeText(context, "Error adding service: ${e.message}", Toast.LENGTH_SHORT).show()
                }
        }
    }

    private fun loadServices() {
        db.collection("services")
            .get()
            .addOnSuccessListener { result ->
                serviceListLayout.removeAllViews()
                for (document in result) {
                    val service = document.getString("service")
                    if (service != null) {
                        addServiceView(service)
                    }
                }
            }
            .addOnFailureListener { e ->
                Toast.makeText(context, "Error loading services: ${e.message}", Toast.LENGTH_SHORT).show()
            }
    }

    private fun addServiceView(service: String) {
        val serviceTextView = EditText(context)
        serviceTextView.setText(service)
        serviceListLayout.addView(serviceTextView)
    }
}
