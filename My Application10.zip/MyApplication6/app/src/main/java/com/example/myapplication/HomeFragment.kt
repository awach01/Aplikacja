package com.example.myapplication

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import androidx.fragment.app.Fragment
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.firestore.FirebaseFirestore

class HomeFragment : Fragment() {

    private lateinit var auth: FirebaseAuth
    private lateinit var db: FirebaseFirestore

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        val view = inflater.inflate(R.layout.fragment_home, container, false)

        val viewAppointmentsButton: Button = view.findViewById(R.id.viewAppointmentsButton)
        val uploadPhotosButton: Button = view.findViewById(R.id.buttonUploadPhotos)
        val contactInfoButton: Button = view.findViewById(R.id.buttonContactInfo)
        val serviceListButton: Button = view.findViewById(R.id.buttonServiceList)
        val reviewButton: Button = view.findViewById(R.id.buttonReview)
        val adminButton: Button = view.findViewById(R.id.buttonAdmin)

        auth = FirebaseAuth.getInstance()
        db = FirebaseFirestore.getInstance()

        viewAppointmentsButton.setOnClickListener {
            val fragment = AppointmentsFragment()
            requireActivity().supportFragmentManager.beginTransaction()
                .replace(R.id.container, fragment)
                .addToBackStack(null)
                .commit()
        }

        uploadPhotosButton.setOnClickListener {
            val fragment = PhotoUploadFragment()
            requireActivity().supportFragmentManager.beginTransaction()
                .replace(R.id.container, fragment)
                .addToBackStack(null)
                .commit()
        }

        contactInfoButton.setOnClickListener {
            val fragment = ContactFragment()
            requireActivity().supportFragmentManager.beginTransaction()
                .replace(R.id.container, fragment)
                .addToBackStack(null)
                .commit()
        }

        serviceListButton.setOnClickListener {
            val fragment = ServiceListFragment()
            requireActivity().supportFragmentManager.beginTransaction()
                .replace(R.id.container, fragment)
                .addToBackStack(null)
                .commit()
        }

        reviewButton.setOnClickListener {
            val fragment = ReviewFragment()
            requireActivity().supportFragmentManager.beginTransaction()
                .replace(R.id.container, fragment)
                .addToBackStack(null)
                .commit()
        }

        checkIfAdmin(adminButton)

        return view
    }

    private fun checkIfAdmin(adminButton: Button) {
        val userId = auth.currentUser?.uid
        userId?.let {
            db.collection("users").document(it).get()
                .addOnSuccessListener { document ->
                    if (document != null && document.exists()) {
                        val isAdmin = document.getBoolean("isAdmin") ?: false
                        if (isAdmin) {
                            adminButton.visibility = View.VISIBLE
                            adminButton.setOnClickListener {
                                val fragment = AdminFragment()
                                requireActivity().supportFragmentManager.beginTransaction()
                                    .replace(R.id.container, fragment)
                                    .addToBackStack(null)
                                    .commit()
                            }
                        } else {
                            adminButton.visibility = View.GONE
                        }
                    } else {
                        adminButton.visibility = View.GONE
                    }
                }
                .addOnFailureListener {
                    adminButton.visibility = View.GONE
                }
        }
    }
}
