package com.example.myapplication

import android.os.Bundle
import android.view.GestureDetector
import android.view.LayoutInflater
import android.view.MotionEvent
import android.view.View
import android.view.ViewGroup
import android.widget.TextView
import androidx.core.view.GestureDetectorCompat
import androidx.fragment.app.Fragment

class ContactFragment : Fragment() {

    private lateinit var gestureDetector: GestureDetectorCompat

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        // Inflate the layout for this fragment
        return inflater.inflate(R.layout.fragment_contact, container, false)
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        // Znajdź widoki za pomocą findViewById
        val contactHours: TextView = view.findViewById(R.id.contact_hours)
        val contactDentist: TextView = view.findViewById(R.id.contact_dentist)
        val contactAssistant: TextView = view.findViewById(R.id.contact_assistant)
        val contactAddress: TextView = view.findViewById(R.id.contact_address)
        val contactPhone: TextView = view.findViewById(R.id.contact_phone)
        val contactEmail: TextView = view.findViewById(R.id.contact_email)

        // Ustaw dane kontaktowe
        contactHours.text = "8:00-20:00 (dni robocze)"
        contactDentist.text = "Stomatolog Adrian Wach"
        contactAssistant.text = "Asystent stomatologiczny Marek Wach"
        contactAddress.text = "ul. Prac Inżyniera 56/21, Kraków"
        contactPhone.text = "+48 123 123 123"
        contactEmail.text = "gabinetpraca@interia.pl"

        // Inicjalizacja GestureDetector
        gestureDetector = GestureDetectorCompat(requireContext(), SwipeGestureListener())
        view.setOnTouchListener { _, event ->
            gestureDetector.onTouchEvent(event)
        }
    }

    inner class SwipeGestureListener : GestureDetector.SimpleOnGestureListener() {
        private val SWIPE_THRESHOLD = 100
        private val SWIPE_VELOCITY_THRESHOLD = 100

        override fun onFling(
            e1: MotionEvent?,
            e2: MotionEvent,
            velocityX: Float,
            velocityY: Float
        ): Boolean {
            if (e1 != null && e2 != null) {
                val diffX = e2.x - e1.x
                val diffY = e2.y - e1.y
                if (Math.abs(diffX) > Math.abs(diffY)) {
                    if (Math.abs(diffX) > SWIPE_THRESHOLD && Math.abs(velocityX) > SWIPE_VELOCITY_THRESHOLD) {
                        if (diffX > 0) {
                            onSwipeRight()
                        }
                        return true
                    }
                }
            }
            return false
        }
    }

    private fun onSwipeRight() {
        parentFragmentManager.popBackStack()
        activity?.overridePendingTransition(R.anim.slide_in_left, R.anim.slide_out_right)
    }
}
